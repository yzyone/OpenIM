# 源码部署-集群



kafka/mongos/redis集群部署 

以及如何部署IM集群



