# Docker部署
小白从0开始部署， 包括docker/docker-compose 安装 启动 检测等。

集成minio等





