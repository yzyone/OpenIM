sdk将连接到[登录时指定]()的websocket地址对应的Open IM Server

