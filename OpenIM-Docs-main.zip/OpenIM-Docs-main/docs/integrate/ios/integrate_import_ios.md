
[![Version](https://img.shields.io/cocoapods/v/OpenIMSDK.svg?style=flat)](https://cocoapods.org/pods/OpenIMSDK)

# 导入工程(iOS)

  采用@imprt的方式导入

```zsh
@import OpenIMSDK;

```


