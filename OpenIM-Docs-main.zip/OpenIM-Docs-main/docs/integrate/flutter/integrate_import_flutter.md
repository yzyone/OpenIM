# 导入工程(flutter)

- 点击前往[Dart packages](https://pub.flutter-io.cn/packages/flutter_openim_sdk/install)查看详情

## 添加package

```bash
flutter pub add flutter_openim_sdk
```



## 添加依赖

```dart
dependencies:
  flutter_openim_sdk: any
```

