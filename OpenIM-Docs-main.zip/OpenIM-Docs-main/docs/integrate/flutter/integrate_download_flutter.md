# SDK下载(Flutter)

[点击这里](https://github.com/OpenIMSDK/Open-IM-SDK-Flutter)下载最新OpenIM Flutter SDK包。

