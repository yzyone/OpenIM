# 离线插件包

[点击这里](https://github.com/OpenIMSDK/Open-IM-SDK-Uniapp)下载OpenIM最新uniapp原生插件包，同时支持安卓端、iOS。

