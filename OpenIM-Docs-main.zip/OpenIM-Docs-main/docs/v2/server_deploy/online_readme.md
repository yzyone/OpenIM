# 重点配置说明

分别针对docker-compose部署和源码/k8s部署来说明

## docker-compose部署

