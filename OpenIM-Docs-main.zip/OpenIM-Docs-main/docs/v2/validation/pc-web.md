# web/pc验证

web仅限于外网验证[web验证](https://doc.rentsoft.cn/#/js_v2/sdk_integrate/development?id=%e5%9c%a8%e7%ba%bf%e6%b5%8b%e8%af%95)

如果纯内网环境建议用[pc应用验证](https://doc.rentsoft.cn/#/js_v2/sdk_integrate/development?id=electron%e5%ba%94%e7%94%a8%e4%b8%8b%e8%bd%bd)