# APP快速验证注册步骤
## 1、[下载app](https://doc.rentsoft.cn/#/demo/download_demo)

## 2、双击图标修改自行搭建的服务器ip
![修改ip1](../../images/app_verification_1.jpg) ![修改ip2](../../images/app_verification_2.jpg)
## 3、利用手机号或者邮箱注册 (超级验证码为6个6)
![注册](../../images/app_verification_3.jpg) ![填写验证码](../../images/app_verification_4.jpg) ![填写个人信息](../../images/app_verification_5.jpg)

## 4、进入聊天界面开始发送消息测试
![发消息测试1](../../images/app_verification_6.jpg) ![发消息测试2](../../images/app_verification_7.jpg)

