```MessageInfo:聊天记录信息
{
"clientMsgID": "09501ab4ce6c6045e6de684512496cad",
"serverMsgID": "2022-01-24 14:18:04-openIM100-6906824559772831383",
"createTime": 1643005091612,
"sendTime": 1643005091612,
"sessionType": 1,
"sendID": "openIM100",
"recvID": "openIM101",
"msgFrom": 100,
"contentType": 101,
"platformID": 1,
"senderNickname": "sksksksksk",
"senderFaceUrl": "",
"groupID": "",
"content": "mmmmmmmmtest:Gordon->skopenIM100:openIM101:",
"seq": 171880,
"isRead": false,
"status": 2,
"offlinePush": {
"title": "232",
"desc": "er",
"ex": "",
"iOSPushSound": "",
"iOSBadgeCount": true
},
"attachedInfo": "",
"ex": "",
"pictureElem": {
"sourcePath": "",
"sourcePicture": {
"uuid": "",
"type": "",
"size": 0,
"width": 0,
"height": 0,
"url": ""
},
"bigPicture": {
"uuid": "",
"type": "",
"size": 0,
"width": 0,
"height": 0,
"url": ""
},
"snapshotPicture": {
"uuid": "",
"type": "",
"size": 0,
"width": 0,
"height": 0,
"url": ""
}
},
"soundElem": {
"uuid": "",
"soundPath": "",
"sourceUrl": "",
"dataSize": 0,
"duration": 0
},
"videoElem": {
"videoPath": "",
"videoUUID": "",
"videoUrl": "",
"videoType": "",
"videoSize": 0,
"duration": 0,
"snapshotPath": "",
"snapshotUUID": "",
"snapshotSize": 0,
"snapshotUrl": "",
"snapshotWidth": 0,
"snapshotHeight": 0
},
"fileElem": {
"filePath": "",
"uuid": "",
"sourceUrl": "",
"fileName": "",
"fileSize": 0
},
"mergeElem": {
"title": "",
"abstractList": null,
"multiMessage": null
},
"atElem": {
"text": "",
"atUserList": null,
"isAtSelf": false
},
"locationElem": {
"description": "",
"longitude": 0,
"latitude": 0
},
"customElem": {
"data": "",
"description": "",
"extension": ""
},
"quoteElem": {
"text": "",
"quoteMessage": null
},
"NotificationElem": {
"detail": "",
"defaultTips": ""
}
}
```