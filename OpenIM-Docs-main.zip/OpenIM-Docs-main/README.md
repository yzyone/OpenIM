# OpenIM-Docs

# dev

```bash
cd ../docs
docsify serve
```